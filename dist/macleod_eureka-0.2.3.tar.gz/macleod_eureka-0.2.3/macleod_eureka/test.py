import parserlib

parserlib.parse_clif("C:/Users/gunna/Documents/code/rcc_basic.clif")

import check_consistency_lib as cc

cc.main("C:/Users/gunna/Documents/code/rcc_basic.clif")